create database if not exists booking;

create table if not exists booking.registered_users(
    id int auto_increment primary key, firstName varchar(50),
    lastName varchar(50), username varchar(40), email varchar(250) unique,
    user_password varchar(100), agree_terms varchar(3), user_address text,
    city varchar(300), region text,
    zipcode varchar(10), country text,
    phoneno bigint unique, dob varchar(10),
    gender varchar(10), dp longblob
    );

create table if not exists booking.tour(
    tour_id int auto_increment primary key,
    title text not null, loc_ation text not null, des_cription text not null,
    charges bigint not null, travel_time text not null, about text not null,
    seniors_age int not null, youths_age int not null, childrens_age int not null,
    adults_age int not null, infants_age int not null, senior_per_charge bigint not null,
    youth_per_charge bigint not null, children_per_charge bigint not null, 
    adult_per_charge bigint not null, infant_per_charge bigint not null, img longblob,
    available_lang text not null, duration text not null, typ_e text not null, transportation text, guide text,
	month text not null, tour_type text not null, level text not null, price_filter text not null
);

create table if not exists booking.excursions(
    tour_id int auto_increment primary key,
    title text not null, loc_ation text not null, des_cription text not null,
    charges bigint not null, travel_time text not null, about text not null,
    seniors_age int not null, youths_age int not null, childrens_age int not null,
    adults_age int not null, infants_age int not null, senior_per_charge bigint not null,
    youth_per_charge bigint not null, children_per_charge bigint not null, 
    adult_per_charge bigint not null, infant_per_charge bigint not null, img longblob,
    available_lang text not null, duration text not null, typ_e text not null, transportation text, guide text,
	month text not null, tour_type text not null, level text not null, price_filter text not null
);

create table if not exists booking.book_tour (
    book_id int auto_increment primary key,
    user_id int,
    -- tour_id int,

    title text not null, loc_ation text not null, des_cription text not null,
    charges bigint not null, travel_time text not null, about text not null,
    seniors_age int not null, youths_age int not null, childrens_age int not null,
    adults_age int not null, infants_age int not null, senior_charges bigint not null,
    youth_charges bigint not null, children_charges bigint not null, 
    adult_charges bigint not null, infant_charges bigint not null, img longblob,
    available_lang text not null, duration text not null, typ_e text not null, transportation text, guide text, 
    total_charges bigint, booked_date text, tour_id int, excursion_id int,

    foreign key (user_id) references booking.registered_users(id),
    -- foreign key (tour_id) references booking.tour(tour_id),
    -- foreign key (tour_id) references booking.excursions(tour_id)

);

create table if not exists booking.booked_tours (
    booked_id int auto_increment primary key,
    user_id int,
    -- tour_id int,

    title text not null, loc_ation text not null, des_cription text not null,
    charges bigint not null, travel_time text not null, about text not null,
    seniors_age int not null, youths_age int not null, childrens_age int not null,
    adults_age int not null, infants_age int not null, senior_charges bigint not null,
    youth_charges bigint not null, children_charges bigint not null, 
    adult_charges bigint not null, infant_charges bigint not null, img longblob,
    available_lang text not null, duration text not null, typ_e text not null, transportation text, guide text,
    total_charges bigint, booked_date text, tour_id int, excursion_id int;

    foreign key (user_id) references booking.registered_users(id),
    -- foreign key (tour_id) references booking.tour(tour_id),
    -- foreign key (tour_id) references booking.excursions(tour_id)
);

create table if not exists booking.transport (
    transport_id int auto_increment primary key,
    title text not null, vehicle_name text not null, des_cription text not null, 
    about text not null, person_capacity int not null, luggage_capacity int not null, 
    travel_time text not null, charges_per_hour bigint not null, 
    seniors_age int not null, youths_age int not null, 
    childrens_age int not null, adults_age int not null, 
    infants_age int not null, available_lang text not null, 
    mobile_ticket text not null, senior_per_charge bigint not null, 
    youth_per_charge bigint not null, children_per_charge bigint not null, 
    adult_per_charge bigint not null, infant_per_charge bigint not null, img longblob, category text not null
);

create table if not exists booking.hotels(
    hotel_id int auto_increment primary key,
    title text not null, hotel_name text not null, des_cription text not null, ratings int not null,
    dollar int not null, popular_with text not null, amenities text not null, about text not null, 
    loc_ation text not null, available_lang text not null, mobile_ticket text not null, duration int not null,
    seniors_age int not null, youths_age int not null, childrens_age int not null, adults_age int not null, 
    infants_age int not null, senior_per_charge bigint not null, 
    youth_per_charge bigint not null, children_per_charge bigint not null, 
    adult_per_charge bigint not null, infant_per_charge bigint not null, img longblob, 
    room_type text not null, bed_type text not null, other_requests text not null, charges bigint not null
);

-- INSERT INTO booking.hotels (
--     title, hotel_name, des_cription, ratings, dollar,  popular_with,
--      amenities, about, loc_ation, available_lang,  mobile_ticket,  duration,  seniors_age, 
--       youths_age, childrens_age, adults_age, infants_age, senior_per_charge, youth_per_charge, children_per_charge, adult_per_charge, 
--       infant_per_charge, room_type, bed_type, other_requests) VALUES
--                             (
--                                 'Sample Hotel 1', 'Hotel ABC', 'A wonderful place to stay.', 4, 3, 'Couples', 'wi-fi, Swimming Pool', 
--                                  'Hotel ABC is a cozy hotel located in a scenic area.', '123 Main Street, City, Country', 
--                                  'English, Spanish', 'Yes', 3, 60, 18, 12, 30, 2, 50, 10, 60, 10, 15, 'Deluxe Suite', 
--                                  'King Size', 'Please provide extra towels.');



-- INSERT INTO transport (title, vehicle_name, des_cription, about, person_capacity, luggage_capacity, travel_time, charges_per_hour, seniors_age, youths_age, childrens_age, adults_age, infants_age, available_lang, mobile_ticket, senior_per_charge, youth_per_charge, children_per_charge, adult_per_charge, infant_per_charge, category)
-- VALUES
--     ('Car 3', 'Ford Mustang', 'A sports car for speed enthusiasts', 'Experience the thrill of driving.', 3, 1, '2 hours', 100, 95, 41, 26, 21, 'English', 'Yes', 6, 12, 4, 20, 2, 10,'car'),
--     ('Boat 3', 'Speedboat', 'A high-speed boat for water sports', 'Enjoy water skiing and tubing.', 5, 2, '3 hours', 60, 70, 16, 12, 0, 'English', 'No', 7, 15, 5, 25, 2, 10,'boat'),
--     ('Helicopter 3', 'Robinson R44', 'A scenic helicopter tour', 'Discover breathtaking aerial views.', 4, 0, '1.5 hours', 150, 70, 16, 10, 0, 'English', 'Yes', 12, 18, 4, 25, 2, 10,'helicopter');


