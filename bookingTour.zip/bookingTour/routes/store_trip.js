const db = require('../db')
const express = require('express')
const store_trip = express.Router()

store_trip.post('/:id', async function (req, res) {
    // console.log(req.params.id);
    const loggedIn = req.session.loggedIn;

    if (loggedIn) {
        const user_id = req.session.user;
        let user_json_data = req.body.cardDataArray[0];
        const tour_id = req.params.id;

        const pattern = /(\d+)\s+(\w+)\s+x\s+HK\$(\d+)/g;
        let match;
        const extractedValues = [];

        while ((match = pattern.exec(user_json_data.totalCount)) !== null) {
            const quantity = parseInt(match[1]);
            const type = match[2];
            const price = parseInt(match[3]);

            extractedValues.push({ quantity, type, price });
        }

        const extracted_price = user_json_data.price.match(/\d+/g);
        const total_cost = parseFloat(extracted_price);

        let senior_quantity = 0, youth_quantity = 0, children_quantity = 0, adult_quantity = 0, infant_quantity = 0;

        await extractedValues.forEach(element => {
            if (element.type === "Seniors") {
                senior_quantity = element.quantity;
            } else if (element.type === "Youths") {
                youth_quantity = element.quantity;
            } else if (element.type === "Children") {
                children_quantity = element.quantity;
            } else if (element.type === "Adults") {
                adult_quantity = element.quantity;
            } else if (element.type === "Infants") {
                infant_quantity = element.quantity;
            }
        });

        // console.log("Quantity of Senior is " + senior_quantity);
        // console.log("Quantity of Youth is " + youth_quantity);
        // console.log("Quantity of Children is " + children_quantity);
        // console.log("Quantity of Adult is " + adult_quantity);
        // console.log("Quantity of Infant is " + infant_quantity);


        // console.log(user_json_data);
        // console.log("Total cost = " + total_cost);
        // console.log(extractedValues[0].price);


        const store_user_trip = `insert into book_tour(
            user_id, title, loc_ation, des_cription, total_charges, booked_date, tour_id,
            senior_charges, youth_charges, children_charges, adult_charges, infant_charges, 
            seniors_quantity, youths_quantity, infants_quantity, children_quantity, adults_quantity,
            charges, travel_time, typ_e, available_lang
            ) values(
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                )`;

        await db.query('select * from tour where tour_id = ?', [tour_id], async function (fetch_err, fetched_rows) {
            if (fetch_err) {
                res.send("Something went while fetching trip details");
                return;
            }

            await db.query(store_user_trip,
                [
                    user_id, fetched_rows[0].title, fetched_rows[0].loc_ation,
                    fetched_rows[0].des_cription,
                    total_cost,
                    user_json_data.time,
                    tour_id,
                    fetched_rows[0].senior_per_charge,
                    fetched_rows[0].youth_per_charge,
                    fetched_rows[0].children_per_charge,
                    fetched_rows[0].adult_per_charge,
                    fetched_rows[0].infant_per_charge,
                    senior_quantity,
                    youth_quantity,
                    infant_quantity,
                    children_quantity,
                    adult_quantity,
                    fetched_rows[0].charges,
                    fetched_rows[0].travel_time,
                    fetched_rows[0].typ_e,
                    fetched_rows[0].available_lang,
                ],
                async (insert_err, rows) => {
                    if (insert_err) {
                        res.send('Something went wrong.. or Network issue');
                        console.log("Failed to store trip details...");
                        return;
                    }

                    res.json({
                        message: "Trip booked successfully"
                    });

                    console.log("Trip booked successfully");

                });
        });

    }
    else {
        res.json({
            login_popup: "Login to Continue"
        });
    }
})

module.exports = store_trip;